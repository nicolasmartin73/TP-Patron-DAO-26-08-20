USE centrocovid;

INSERT INTO categorias(id,categoria) VALUES
    (1,'ASINTOMATICO'),
    (2,'SINTOMATICO'),
    (3,'TERAPIA_INTENSIVA');

INSERT INTO medicos (id,nombre,apellido,direccion,telefono,categoria) VALUES
    (1,'Rodolfo','Perez','Aguero 2323','4423 5591','ASINTOMATICO'),
    (2,'Maria','Rodrigues','Aguero 2323','4423 5591','ASINTOMATICO'),
    (3,'Raquel','Garcia','Aguero 2323','4423 5591','ASINTOMATICO'),
    (4,'Juan','Washinton','Aguero 2323','4423 5591','ASINTOMATICO'),
    (5,'Pedro','Perez','Aguero 2323','4423 5591','SINTOMATICO'),
    (6,'Tomas','Aguero','Aguero 2323','4423 5591','SINTOMATICO'),
    (7,'Micaela','Martines','Aguero 2323','4423 5591','SINTOMATICO'),
    (8,'Martha','Zaragocian','Aguero 2323','4423 5591','SINTOMATICO'),
    (9,'Pepe','Perez','Aguero 2323','4423 5591','TERAPIA_INTENSIVA'),
    (10,'Soledad','Aguero','Aguero 2323','4423 5591','TERAPIA_INTENSIVA'),
    (11,'Martina','Xantopulus','Aguero 2323','4423 5591','TERAPIA_INTENSIVA'),
    (12,'Andrea','Perez','Aguero 2323','4423 5591','TERAPIA_INTENSIVA');

INSERT INTO pacientes(id,nombre,apellido,direccion,telefono,categoria,fechaCategorizacion,idMedico) VALUES
    (1,'Maria','Zalazar','Av Rivadavia 2033','48267611','ASINTOMATICO','2020-03-01',1),
    (2,'Josefa','Perez','Av Rivadavia 2033','48267611','ASINTOMATICO','2020-04-12',4),
    (3,'Ramona','Fiolmena','Av Rivadavia 2033','48267611','ASINTOMATICO','2020-03-22',5),
    (4,'Miriam','Washington','Av Rivadavia 2033','48267611','ASINTOMATICO','2021-08-24',3),
    (5,'Alejandra','Sinaloa','Av Rivadavia 2033','48267611','SINTOMATICO','2021-01-25',10),
    (6,'Pedro','Paris','Av Rivadavia 2033','48267611','SINTOMATICO','2020-09-12',7),
    (7,'Nicolas','Sandocan','Av Rivadavia 2033','48267611','SINTOMATICO','2020-10-01',7),
    (8,'Martin','Eternauta','Av Rivadavia 2033','48267611','SINTOMATICO','2020-11-15',7),
    (9,'Gonzalo','Salgado','Av Rivadavia 2033','48267611','TERAPIA_INTENSIVA','2020-12-28',2),
    (10,'Roberto','Guerrin','Av Rivadavia 2033','48267611','TERAPIA_INTENSIVA','2021-01-12',6),
    (11,'Juan','Lascuartetas','Av Rivadavia 2033','48267611','TERAPIA_INTENSIVA','2021-02-12',8),
    (12,'Margarita','Perez','Av Rivadavia 2033','48267611','TERAPIA_INTENSIVA','2021-03-12',9);

INSERT INTO camas (id,estado,idPaciente) VALUES
    (1,'OCUPADA',1),
    (2,'OCUPADA',2),
    (3,'OCUPADA',3),
    (4,'OCUPADA',4),
    (5,'OCUPADA',5),
    (6,'OCUPADA',6),
    (7,'OCUPADA',7),
    (8,'OCUPADA',8),
    (9,'OCUPADA',9),
    (10,'OCUPADA',10),
    (11,'OCUPADA',11),
    (12,'OCUPADA',12),
    (13,'LIBRE',null),
    (14,'LIBRE',null),
    (15,'LIBRE',null),
    (16,'LIBRE',null),
    (17,'LIBRE',null),
    (18,'LIBRE',null),
    (19,'LIBRE',null),
    (20,'LIBRE',null);