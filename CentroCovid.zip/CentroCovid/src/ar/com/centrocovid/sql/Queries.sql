USE centrocovid;

-- Consultas Generales.

SELECT * FROM medicos;

SELECT * FROM pacientes;

SELECT * FROM camas;

-- Cuantas camas estan ocupadas.

SELECT COUNT(estado) 'Total Camas Ocupadas' FROM camas WHERE estado LIKE '%OCUPADA%';

-- Cuantas camas estan libres.

SELECT COUNT(estado) 'Total Camas Libres' FROM camas WHERE estado LIKE '%LIBRE%';

-- Porcentaje de camas ocupadas y libres.

SELECT ROUND(
(SELECT COUNT(estado) 'Total Camas Ocupadas' FROM camas WHERE estado LIKE '%OCUPADA%') 
/ 
(SELECT COUNT(id) FROM camas) * 100,0) 'Porcentaje Camas Ocupadas';

SELECT ROUND(
(SELECT COUNT(estado) 'Total Camas Ocupadas' FROM camas WHERE estado LIKE '%LIBRE%') 
/ 
(SELECT COUNT(id) FROM camas) * 100,0) 'Porcentaje Camas Ocupadas';

-- Cuantos pacientes en total estan internados en Centrocovid.

SELECT COUNT(id) 'Total Internados' FROM pacientes;

-- Cuantos pacientes son asintomaticos.

SELECT COUNT(id) 'Total Asintomaticos' FROM pacientes WHERE categoria = 'ASINTOMATICO';

-- Cuantos pacientes son sintomaticos.

SELECT COUNT(id) 'Total Sintomaticos' FROM pacientes WHERE categoria = 'SINTOMATICO';

-- Cuantos pacientes estan en terapia intensiva.

SELECT COUNT(id) 'Total Terapia Intensiva' FROM pacientes WHERE categoria = 'TERAPIA_INTENSIVA';

-- Porcentajes de pacientes asintomaticos, sintomaticos, terapia intensiva.

SELECT ROUND(
(SELECT COUNT(id) 'Total Asintomaticos' FROM pacientes WHERE categoria = 'ASINTOMATICO')
/
(SELECT COUNT(id) FROM pacientes) * 100,0) 'Porcentaje Asintomaticos ';

SELECT ROUND(
(SELECT COUNT(id) 'Total Sintomaticos' FROM pacientes WHERE categoria = 'SINTOMATICO')
/
(SELECT COUNT(id) FROM pacientes) * 100,0) 'Porcentaje Sintomaticos ';

SELECT ROUND(
(SELECT COUNT(id) 'Total Terapia Intensiva' FROM pacientes WHERE categoria = 'TERAPIA_INTENSIVA')
/
(SELECT COUNT(id) FROM pacientes) * 100,0) 'Porcentaje Terapia Intensiva';

-- Cuantos pacientes a su cargo tienen en promedio los medicos asignados a asintomaticos.

SELECT ROUND(
(SELECT COUNT(id) FROM pacientes WHERE categoria = 'ASINTOMATICO')
/
(SELECT COUNT(id) FROM medicos WHERE categoria = 'ASINTOMATICO'),2) 'Avg Pacientes Asin. por Medico';

-- Cuantos pacientes a su cargo tienen en promedio los medicos asignados a sintomaticos.

SELECT ROUND(
(SELECT COUNT(id) FROM pacientes WHERE categoria = 'SINTOMATICO')
/
(SELECT COUNT(id) FROM medicos WHERE categoria = 'SINTOMATICO'),2) 'Avg Pacientes Sint. por Medico';

-- Cuantos pacientes a su cargo tienen en promedio los medicos asignados a terapia intensiva.

SELECT ROUND(
(SELECT COUNT(id) FROM pacientes WHERE categoria = 'TERAPIA_INTENSIVA')
/
(SELECT COUNT(id) FROM medicos WHERE categoria = 'TERAPIA_INTENSIVA'),2) 'Avg Pacientes T_I por Medico';
