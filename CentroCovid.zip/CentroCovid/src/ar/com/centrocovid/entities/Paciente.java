package ar.com.centrocovid.entities;

import ar.com.centrocovid.enums.CategoriaEnum;

public class Paciente {
    int id;
    String nombre;
    String apellido;
    String direccion;
    String telefono;
    CategoriaEnum categoria;
    String fechacategorizacion;
    int idmedico;

    public Paciente() { }

    public Paciente(String nombre, String apellido, String direccion, String telefono, CategoriaEnum categoria, String fechacategorizacion, int idmedico) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono = telefono;
        this.categoria = categoria;
        this.fechacategorizacion = fechacategorizacion;
        this.idmedico = idmedico;
    }

    public Paciente(int id, String nombre, String apellido, String direccion, String telefono, CategoriaEnum categoria, String fechacategorizacion, int idmedico) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono = telefono;
        this.categoria = categoria;
        this.fechacategorizacion = fechacategorizacion;
        this.idmedico = idmedico;
    }

    @Override
    public String toString() {
        return "Paciente{" + "id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", direccion=" + direccion + ", telefono=" + telefono + ", categoria=" + categoria + ", fechacategorizacion=" + fechacategorizacion + ", idmedico=" + idmedico + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public CategoriaEnum getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaEnum categoria) {
        this.categoria = categoria;
    }

    public String getFechacategorizacion() {
        return fechacategorizacion;
    }

    public void setFechacategorizacion(String fechacategorizacion) {
        this.fechacategorizacion = fechacategorizacion;
    }

    public int getIdmedico() {
        return idmedico;
    }

    public void setIdmedico(int idmedico) {
        this.idmedico = idmedico;
    }    
    
}
