package ar.com.centrocovid.entities;
import ar.com.centrocovid.enums.CategoriaEnum;
public class Categoria {
    private int id;
    private CategoriaEnum categoria;

    public Categoria() { }

    public Categoria(CategoriaEnum categoria) {
        this.categoria = categoria;
    }
    
    public Categoria(int id, CategoriaEnum categoria) {
        this.id = id;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "id=" + id + ", categoria=" + categoria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CategoriaEnum getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaEnum categoria) {
        this.categoria = categoria;
    }   
}
