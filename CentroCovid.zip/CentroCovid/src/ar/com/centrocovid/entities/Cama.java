package ar.com.centrocovid.entities;
import ar.com.centrocovid.enums.EstadoEnum;
public class Cama {
    int id;
    EstadoEnum estado;
    int idpaciente;

    public Cama() { }

    public Cama(EstadoEnum estado) {
        this.estado = estado;
    }

    public Cama(EstadoEnum estado, int idpaciente) {
        this.estado = estado;
        this.idpaciente = idpaciente;
    }

    public Cama(int id, EstadoEnum estado, int idpaciente) {
        this.id = id;
        this.estado = estado;
        this.idpaciente = idpaciente;
    }

    @Override
    public String toString() {
        return "Cama: " + "id=" + id + ", estado=" + estado + ", idpaciente=" + idpaciente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public EstadoEnum getEstado() {
        return estado;
    }

    public void setEstado(EstadoEnum estado) {
        this.estado = estado;
    }

    public int getIdpaciente() {
        return idpaciente;
    }

    public void setIdpaciente(int idpaciente) {
        this.idpaciente = idpaciente;
    }   
}
