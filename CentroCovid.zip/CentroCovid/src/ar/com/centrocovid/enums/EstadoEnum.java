package ar.com.centrocovid.enums;
public enum EstadoEnum {OCUPADA,LIBRE}