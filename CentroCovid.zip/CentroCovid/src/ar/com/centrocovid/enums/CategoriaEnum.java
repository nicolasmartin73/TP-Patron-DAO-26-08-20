package ar.com.centrocovid.enums;
public enum CategoriaEnum {ASINTOMATICO, SINTOMATICO, TERAPIA_INTENSIVA}
