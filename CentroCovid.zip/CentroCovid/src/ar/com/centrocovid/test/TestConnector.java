package ar.com.centrocovid.test;
import ar.com.centrocovid.connectors.Connector;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
public class TestConnector {
    public static void main(String[] args) throws Exception{
        Connection conn=Connector.getConnection();
        
        String query = "INSERT INTO medicos (nombre,apellido,direccion,telefono,categoria) "
                        + "VALUES ('Pepe','Mujica','Aguero 2323','4423 5591','ASINTOMATICO')";
        Statement st = conn.createStatement();
        st.execute(query);
        
        Connector
                .getConnection()
                .createStatement()
                .execute("INSERT INTO medicos (nombre,apellido,direccion,telefono,categoria) "
                        + "VALUES ('Martha','Salguero','Aguero 2323','4423 5591','TERAPIA_INTENSIVA')");    
        
        ResultSet rs = Connector.getConnection().createStatement().executeQuery("SELECT * FROM medicos");
        while(rs.next()){
            System.out.println(
            rs.getInt("id")+", "+
            rs.getString("nombre")+", "+
            rs.getString("apellido")+", "+
            rs.getString("direccion")+", "+
            rs.getString("telefono")+", "+
            rs.getString("categoria")+", "
            );
        }
        
    }
    
}
