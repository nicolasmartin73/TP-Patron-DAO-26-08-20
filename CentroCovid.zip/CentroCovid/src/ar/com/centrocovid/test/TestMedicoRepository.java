package ar.com.centrocovid.test;
import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.repositories.interfaces.I_MedicoRepository;
import ar.com.centrocovid.repositories.jdbc.MedicoRepository;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.enums.CategoriaEnum;


public class TestMedicoRepository {
    public static void main(String[] args) {
        I_MedicoRepository mr= new MedicoRepository(Connector.getConnection());

        System.out.println("\n*************** SAVE ****************************************");
        Medico medico= new Medico("Pepe", "Pepito", "Rivadavia 20", "4854-9852", CategoriaEnum.SINTOMATICO);
        mr.save(medico);
        System.out.println(medico);
        
        System.out.println("\n*************** GET ALL ****************************************");
        mr.getAll().forEach(System.out::println);
        
        System.out.println("\n*************** GET LIKE NOMBRE ****************************************");
        mr.getLikeNombre("pepe").forEach(System.out::println);
        
        System.out.println("\n*************** GET LIKE APELLIDO ****************************************");
        mr.getLikeApellido("Aguero").forEach(System.out::println);

        System.out.println("\n*************** GET BY CATEGORIA ****************************************");
        mr.getByCategoria(CategoriaEnum.TERAPIA_INTENSIVA).forEach(System.out::println);
    
        System.out.println("\n*************** REMOVE ****************************************");
        mr.remove(mr.getById(13));
        mr.getAll().forEach(System.out::println);
    
        System.out.println("\n*************** UP DATE ****************************************");
        medico = mr.getById(6);
        if(medico!=null && medico.getId()!=0){
            medico.setApellido("MongoPirulo");
            medico.setCategoria(CategoriaEnum.SINTOMATICO);
            mr.update(medico);
        }
        System.out.println(medico);        
    }    
}
