package ar.com.centrocovid.test;
import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.entities.Cama;
import ar.com.centrocovid.enums.EstadoEnum;
import ar.com.centrocovid.repositories.interfaces.I_CamaRepository;
import ar.com.centrocovid.repositories.jdbc.CamaRepository;
public class TestCamaRepository {
    public static void main(String[] args) {
        I_CamaRepository cr= new CamaRepository(Connector.getConnection());

        System.out.println("\n*************** SAVE ****************************************");
        Cama cama= new Cama(EstadoEnum.OCUPADA, 1);
        cr.save(cama);
        System.out.println(cama);
        
        System.out.println("\n*************** GET ALL ****************************************");
        cr.getAll().forEach(System.out::println);
        
        System.out.println("\n*************** GET BY ESTDADO ****************************************");
        cr.getByEstado(EstadoEnum.LIBRE).forEach(System.out::println);
        
        System.out.println("\n*************** GET BY ID PACEINTE ****************************************");
        System.out.println(cr.getByIdPaciente(12));

        System.out.println("\n*************** REMOVE ****************************************");
        cr.remove(cr.getById(5));
        cr.getAll().forEach(System.out::println);
    
        System.out.println("\n*************** UP DATE ****************************************");
        cama = cr.getById(6);
        if(cama!=null && cama.getId()!=0){
            cama.setEstado(EstadoEnum.OCUPADA);
            cr.update(cama);
        }
        System.out.println(cama);        
    }
}
