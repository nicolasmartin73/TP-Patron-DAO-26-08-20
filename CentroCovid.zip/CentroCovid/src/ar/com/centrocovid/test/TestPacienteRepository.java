package ar.com.centrocovid.test;
import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.entities.Paciente;
import ar.com.centrocovid.enums.CategoriaEnum;
import ar.com.centrocovid.repositories.interfaces.I_PacienteRepository;
import ar.com.centrocovid.repositories.jdbc.PacienteRepository;
public class TestPacienteRepository {
    public static void main(String[] args) {
        I_PacienteRepository pr= new PacienteRepository(Connector.getConnection());

        System.out.println("\n*************** SAVE ****************************************");
        Paciente paciente= new Paciente("Zulma", "Garcia", "Udaondo 300", "4873-9152", CategoriaEnum.SINTOMATICO,"2020-02-12",1);
        pr.save(paciente);
        System.out.println(paciente);
        
        System.out.println("\n*************** GET ALL ****************************************");
        pr.getAll().forEach(System.out::println);
        
        System.out.println("\n*************** GET LIKE NOMBRE ****************************************");
        pr.getLikeNombre("zulma").forEach(System.out::println);
        
        System.out.println("\n*************** GET LIKE APELLIDO ****************************************");
        pr.getLikeApellido("Zalazar").forEach(System.out::println);

        System.out.println("\n*************** GET BY CATEGORIA ****************************************");
        pr.getByCategoria(CategoriaEnum.TERAPIA_INTENSIVA).forEach(System.out::println);
        
        System.out.println("\n*************** GET BY FECHA DE CATEGORIZACION ****************************************");
        pr.getByFechaCategorizacion("2020-11-15").forEach(System.out::println);
        
        System.out.println("\n*************** REMOVE ****************************************");
        pr.remove(pr.getById(18));
        pr.getAll().forEach(System.out::println);
    
        System.out.println("\n*************** UP DATE ****************************************");
        paciente = pr.getById(6);
        if(paciente!=null && paciente.getId()!=0){
            paciente.setApellido("Manolos");
            paciente.setCategoria(CategoriaEnum.TERAPIA_INTENSIVA);
            pr.update(paciente);
        }
        System.out.println(paciente);        
    }
}
