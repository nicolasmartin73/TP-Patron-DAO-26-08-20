package ar.com.centrocovid.gui;
import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.enums.CategoriaEnum;
import ar.com.centrocovid.repositories.interfaces.I_MedicoRepository;
import ar.com.centrocovid.repositories.interfaces.I_PacienteRepository;
import ar.com.centrocovid.repositories.jdbc.MedicoRepository;
import ar.com.centrocovid.repositories.jdbc.PacienteRepository;
import ar.com.centrocovid.utils.swing.Table;
import ar.com.centrocovid.utils.swing.Validator;
import javax.swing.JOptionPane;
public class FormMedicos extends javax.swing.JInternalFrame {
    private I_MedicoRepository mr = new MedicoRepository(Connector.getConnection());
    private I_PacienteRepository pr = new PacienteRepository(Connector.getConnection());
    public FormMedicos() {
        super( 
                "Gestion de Médicos",           //title
                false,                           //resizable
                true,                           //closable - boton de cerrar
                false,                           //maximizable - boton de maximizar
                true                            //iconable - boton de minimizar
        );
        initComponents();
        
        cargarElementos();
    }

    private void cargarElementos() {
        cmbCategoria.removeAllItems();
        for(CategoriaEnum c: CategoriaEnum.values()) cmbCategoria.addItem(c);
        
        new Table().cargar(tblMedicos, pr.getAll());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        cmbCategoria = new javax.swing.JComboBox<>();
        lblInfo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMedicos = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        txtBuscarMedico = new javax.swing.JTextField();
        btnDarDeBaja = new javax.swing.JButton();
        btnListadoDePacientes = new javax.swing.JButton();

        jLabel1.setText("Nombre:");

        jLabel2.setText("Apellido:");

        jLabel3.setText("Direccion:");

        jLabel4.setText("Telefono:");

        jLabel5.setText("Categoria:");

        lblInfo.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lblInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jButton1.setText("Dar de Alta");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(tblMedicos);

        jLabel6.setText("Buscar Medico por Apellido:");

        txtBuscarMedico.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarMedicoKeyReleased(evt);
            }
        });

        btnDarDeBaja.setText("Dar de Baja");
        btnDarDeBaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDarDeBajaActionPerformed(evt);
            }
        });

        btnListadoDePacientes.setText("Mostrar Listado de Pacientes");
        btnListadoDePacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListadoDePacientesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(105, 105, 105)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(cmbCategoria, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtTelefono, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDireccion, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtApellido, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtBuscarMedico))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 640, Short.MAX_VALUE)
                                    .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnDarDeBaja, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnListadoDePacientes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 16, Short.MAX_VALUE))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(jButton1)
                .addGap(12, 12, 12)
                .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtBuscarMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnListadoDePacientes)
                .addGap(11, 11, 11)
                .addComponent(btnDarDeBaja)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // EVENTO DAR DE ALTA
        if(!validar()) return;
        Medico medico = new Medico( 
                txtNombre.getText(), 
                txtApellido.getText(), 
                txtDireccion.getText(), 
                txtTelefono.getText(), 
                cmbCategoria.getItemAt(cmbCategoria.getSelectedIndex())
        );
        mr.save(medico);
        lblInfo.setText(" El Dr. " + medico.getApellido() + " fue dado de alta con el Id: "+ medico.getId());
        limpiar();
        cargarElementos();        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void limpiar(){
                txtNombre.setText(""); 
                txtNombre.requestFocus();
                txtApellido.setText(""); 
                txtDireccion.setText(""); 
                txtTelefono.setText(""); 
                cmbCategoria.setSelectedIndex(0);
    }
    
    private void txtBuscarMedicoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarMedicoKeyReleased
        // EVENTO BUSCAR MEDICO
        new Table().cargar(tblMedicos, mr.getLikeApellido(txtBuscarMedico.getText()));
    }//GEN-LAST:event_txtBuscarMedicoKeyReleased

    private void btnDarDeBajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDarDeBajaActionPerformed
        // EVENTO DAR DE BAJA
        int fila = tblMedicos.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblMedicos.getValueAt(fila, 0);
        if(JOptionPane.showConfirmDialog(this, "Desea dar de baja al Dr. ID: "+id+"?") != 0) return;
        Medico medico = mr.getById(id);
        if(pr.getByMedico(medico).size()!=0){
            JOptionPane.showMessageDialog(this, "El Dr. ID: "+id+" no puede ser dado de baja porque tiene pacientes a su cargo","Error",JOptionPane.ERROR_MESSAGE);
            return;        
        }
        mr.remove(medico);
        cargarElementos();       
    }//GEN-LAST:event_btnDarDeBajaActionPerformed

    private void btnListadoDePacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListadoDePacientesActionPerformed
        // EVENTO MOSTRAR LISTADO DE PACIENTES
        int fila = tblMedicos.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblMedicos.getValueAt(fila, 0);
        Medico medico = mr.getById(id);
        ListadoDePacientes lp = new ListadoDePacientes(medico);
        this.getParent().add(lp);
        lp.setVisible(true);
    }//GEN-LAST:event_btnListadoDePacientesActionPerformed

    private boolean validar(){
        if(!new Validator(txtNombre).length(3, 20)) return false;
        if(!new Validator(txtApellido).length(3, 20)) return false;
        if(!new Validator(txtDireccion).length(3, 20)) return false;
        if(!new Validator(txtTelefono).length(3, 20)) return false;
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDarDeBaja;
    private javax.swing.JButton btnListadoDePacientes;
    private javax.swing.JComboBox<CategoriaEnum> cmbCategoria;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JTable tblMedicos;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscarMedico;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
