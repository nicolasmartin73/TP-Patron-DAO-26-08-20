package ar.com.centrocovid.gui;

import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.entities.Cama;
import ar.com.centrocovid.enums.EstadoEnum;
import ar.com.centrocovid.repositories.interfaces.I_CamaRepository;
import ar.com.centrocovid.repositories.jdbc.CamaRepository;
import ar.com.centrocovid.utils.swing.Table;
import ar.com.centrocovid.utils.swing.Validator;

public class FormCamas extends javax.swing.JInternalFrame {
    private I_CamaRepository cr = new CamaRepository(Connector.getConnection());
    public FormCamas() {
        super( 
                "Gestion de Cámas",           //title
                false,                           //resizable
                true,                           //closable - boton de cerrar
                false,                           //maximizable - boton de maximizar
                true                            //iconable - boton de minimizar
        );
        initComponents();
        cargarElementos();
    }
    
    private void cargarElementos() {
        cmbEstado.removeAllItems();
        for(EstadoEnum c: EstadoEnum.values()) cmbEstado.addItem(c);   
        
        new Table().cargar(tblCamas, cr.getAll());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cmbEstado = new javax.swing.JComboBox<>();
        txtIdPaciente = new javax.swing.JTextField();
        lblInfo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCamas = new javax.swing.JTable();

        jLabel2.setText("Estado:");

        jLabel3.setText("Id Paciente:");

        lblInfo.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jButton1.setText("Dar de Alta");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Actualizar");

        jScrollPane1.setViewportView(tblCamas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtIdPaciente))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(45, 45, 45)
                        .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(377, 377, 377)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtIdPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // EVENTO DAR DE ALTA
//        if(cmbEstado.equals(EstadoEnum.LIBRE)){
//        Cama cama = new Cama(EstadoEnum.LIBRE);
//        cr.save(cama);
//        lblInfo.setText(" La Cama Id: " + cama.getId()+ " fue dada de alta y esta desocupada.");
//        limpiar();
//        cargarElementos();        
//        }else{        
//        Cama cama = new Cama( 
//            cmbEstado.getItemAt(cmbEstado.getSelectedIndex()),
//            Integer.parseInt(txtIdPaciente.getText())
//        );
//        cr.save(cama);
//        lblInfo.setText(" La Cama Id: " + cama.getId()+ " fue dada de alta.");
//        limpiar();
//        cargarElementos();     
//        }
    }//GEN-LAST:event_jButton1ActionPerformed

        private void limpiar(){
                cmbEstado.setSelectedIndex(0);                
                txtIdPaciente.setText(""); 
                txtIdPaciente.requestFocus();
    }
        
//    private boolean validar(){
//        //if(!new Validator(cmbEstado==EstadoEnum.LIBRE).isInteger(1, 400)) return false;
//        if(!new Validator(txtIdPaciente).isInteger(1, 400)) return false;
//        return true;
//    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<EstadoEnum> cmbEstado;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JTable tblCamas;
    private javax.swing.JTextField txtIdPaciente;
    // End of variables declaration//GEN-END:variables
}
