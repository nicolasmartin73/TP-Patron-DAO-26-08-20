package ar.com.centrocovid.gui;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CentroCovid extends javax.swing.JFrame {
    public CentroCovid() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        desktop = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuGestion = new javax.swing.JMenu();
        menuMedicos = new javax.swing.JMenuItem();
        menuPacientes = new javax.swing.JMenuItem();
        menuCamas = new javax.swing.JMenuItem();
        menuTableroDeControl = new javax.swing.JMenuItem();
        menuOpciones = new javax.swing.JMenu();
        menuAcerca = new javax.swing.JMenuItem();
        menuSalir = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenu1.setText("jMenu1");

        jMenuItem4.setText("jMenuItem4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("GestionCentroCovid");

        javax.swing.GroupLayout desktopLayout = new javax.swing.GroupLayout(desktop);
        desktop.setLayout(desktopLayout);
        desktopLayout.setHorizontalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        desktopLayout.setVerticalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 279, Short.MAX_VALUE)
        );

        menuGestion.setText("Gestion");

        menuMedicos.setText("Medicos");
        menuMedicos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuMedicosActionPerformed(evt);
            }
        });
        menuGestion.add(menuMedicos);

        menuPacientes.setText("Pacientes");
        menuPacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuPacientesActionPerformed(evt);
            }
        });
        menuGestion.add(menuPacientes);

        menuCamas.setText("Camas");
        menuCamas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCamasActionPerformed(evt);
            }
        });
        menuGestion.add(menuCamas);

        menuTableroDeControl.setText("Tablero de Control");
        menuTableroDeControl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuTableroDeControlActionPerformed(evt);
            }
        });
        menuGestion.add(menuTableroDeControl);

        jMenuBar1.add(menuGestion);

        menuOpciones.setText("Opciones");

        menuAcerca.setText("Acerca");
        menuAcerca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuAcercaActionPerformed(evt);
            }
        });
        menuOpciones.add(menuAcerca);

        menuSalir.setText("Salir");
        menuSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSalirActionPerformed(evt);
            }
        });
        menuOpciones.add(menuSalir);

        jMenuBar1.add(menuOpciones);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuMedicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuMedicosActionPerformed
        // EVENTO VENTANA MEDICOS
        FormMedicos a = new FormMedicos();
        desktop.add(a);
        a.setVisible(true);
    }//GEN-LAST:event_menuMedicosActionPerformed

    private void menuPacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuPacientesActionPerformed
        // EVENTO VENTANA PACIENTES
        FormPacientes a = new FormPacientes();
        desktop.add(a);
        a.setVisible(true);
    }//GEN-LAST:event_menuPacientesActionPerformed

    private void menuCamasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCamasActionPerformed
        // EVENTO VENTANA CAMAS
        FormCamas a = new FormCamas();
        desktop.add(a);
        a.setVisible(true);
    }//GEN-LAST:event_menuCamasActionPerformed

    private void menuTableroDeControlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuTableroDeControlActionPerformed
        // EVENTO VENTANA TABLERO DE CONTROL
        FormTableroDeControl a = new FormTableroDeControl();
        desktop.add(a);
        a.setVisible(true);
    }//GEN-LAST:event_menuTableroDeControlActionPerformed

    private void menuAcercaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuAcercaActionPerformed
        // EVENTO ACERCA
        JOptionPane.showMessageDialog(this, "Sistema Gestor Centro Covid (1.0)");
    }//GEN-LAST:event_menuAcercaActionPerformed

    private void menuSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSalirActionPerformed
        // EVENTO SALIR
        System.exit(0);
    }//GEN-LAST:event_menuSalirActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CentroCovid.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CentroCovid.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CentroCovid.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CentroCovid.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CentroCovid().setVisible(true);
            }
        });
    }

    public JDesktopPane getDesktop() {
        return desktop;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktop;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem menuAcerca;
    private javax.swing.JMenuItem menuCamas;
    private javax.swing.JMenu menuGestion;
    private javax.swing.JMenuItem menuMedicos;
    private javax.swing.JMenu menuOpciones;
    private javax.swing.JMenuItem menuPacientes;
    private javax.swing.JMenuItem menuSalir;
    private javax.swing.JMenuItem menuTableroDeControl;
    // End of variables declaration//GEN-END:variables
}
