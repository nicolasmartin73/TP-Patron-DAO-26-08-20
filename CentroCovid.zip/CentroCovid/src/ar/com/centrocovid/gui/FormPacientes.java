package ar.com.centrocovid.gui;
import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.entities.Paciente;
import ar.com.centrocovid.enums.CategoriaEnum;
import ar.com.centrocovid.repositories.interfaces.I_CamaRepository;
import ar.com.centrocovid.repositories.interfaces.I_MedicoRepository;
import ar.com.centrocovid.repositories.interfaces.I_PacienteRepository;
import ar.com.centrocovid.repositories.jdbc.CamaRepository;
import ar.com.centrocovid.repositories.jdbc.MedicoRepository;
import ar.com.centrocovid.repositories.jdbc.PacienteRepository;
import ar.com.centrocovid.utils.swing.Table;
import ar.com.centrocovid.utils.swing.Validator;
import javax.swing.JOptionPane;
public class FormPacientes extends javax.swing.JInternalFrame {
    private I_MedicoRepository mr = new MedicoRepository(Connector.getConnection());
    private I_PacienteRepository pr = new PacienteRepository(Connector.getConnection());
    private I_CamaRepository cr = new CamaRepository(Connector.getConnection());
    public FormPacientes() {
        super( 
                "Gestion de Pacientes",           //title
                false,                           //resizable
                true,                           //closable - boton de cerrar
                false,                           //maximizable - boton de maximizar
                true                            //iconable - boton de minimizar
        );
        initComponents();
        
        cargarElementos();
        
    }
    
    private void cargarElementos() {
        cmbCategoria.removeAllItems();
        for(CategoriaEnum c: CategoriaEnum.values()) cmbCategoria.addItem(c);
        
        cmbIdMedicos.removeAllItems();
        mr.getAll().forEach(cmbIdMedicos::addItem);
        
        new Table().cargar(tblPacientes, pr.getAll());        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtFechaCategorizacion = new javax.swing.JTextField();
        cmbCategoria = new javax.swing.JComboBox<>();
        lblInfo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        btnDaDeAlta = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPacientes = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        txtBuscarPaciente = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtBuscarCategoria = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        cmbIdMedicos = new javax.swing.JComboBox<>();

        jLabel1.setText("Nombre:");

        jLabel2.setText("Apellido:");

        jLabel3.setText("Direccion:");

        jLabel4.setText("Telefono:");

        jLabel5.setText("Categoria:");

        jLabel6.setText("Fecha de Categorizacion:");

        jLabel7.setText("Id Medico:");

        lblInfo.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lblInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        btnDaDeAlta.setText("Dar de Alta");
        btnDaDeAlta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDaDeAltaActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(tblPacientes);

        jLabel8.setText("Buscar Paciente por Apellido:");

        txtBuscarPaciente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarPacienteKeyReleased(evt);
            }
        });

        jLabel9.setText("Buscar Pacientes por Categoria:");

        txtBuscarCategoria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarCategoriaKeyReleased(evt);
            }
        });

        jButton1.setText("Dar de Baja");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel10.setText("Formato de Fecha: aaaa-mm-dd");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 783, Short.MAX_VALUE)
                    .addComponent(btnDaDeAlta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbCategoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(26, 26, 26)
                        .addComponent(txtNombre))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(24, 24, 24)
                        .addComponent(txtApellido))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDireccion))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(21, 21, 21)
                        .addComponent(txtTelefono))
                    .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtBuscarPaciente)
                            .addComponent(txtBuscarCategoria)))
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtFechaCategorizacion, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37)
                                .addComponent(jLabel10))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbIdMedicos, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtFechaCategorizacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cmbIdMedicos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnDaDeAlta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(txtBuscarPaciente, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(txtBuscarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDaDeAltaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDaDeAltaActionPerformed
        // EVENTO DAR DE ALTA
//        if(!validar()) return;
//        Paciente paciente = new Paciente( 
//                txtNombre.getText(), 
//                txtApellido.getText(), 
//                txtDireccion.getText(), 
//                txtTelefono.getText(), 
//                cmbCategoria.getItemAt(cmbCategoria.getSelectedIndex()),
//                txtFechaCategorizacion.getText(),
//                cmbIdMedicos.getItemAt(cmbIdMedicos.getSelectedIndex()).getId()
//        );
//        pr.save(paciente);
//        lblInfo.setText(" El paciente " + paciente.getApellido() + " fue dado de alta con el Id: "+ paciente.getId());
//        limpiar();
//        cargarElementos();
    }//GEN-LAST:event_btnDaDeAltaActionPerformed

    private void txtBuscarPacienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarPacienteKeyReleased
        // EVENTO BUSCAR PACIENTE
        new Table().cargar(tblPacientes, pr.getLikeApellido(txtBuscarPaciente.getText()));
    }//GEN-LAST:event_txtBuscarPacienteKeyReleased

    private void txtBuscarCategoriaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarCategoriaKeyReleased
        // EVENTO BUSCAR CATEGORIA
        new Table().cargar(tblPacientes, pr.getLikeCategoria(txtBuscarCategoria.getText()));
    }//GEN-LAST:event_txtBuscarCategoriaKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // EVENTO DAR DE BAJA
        int fila = tblPacientes.getSelectedRow();
        if(fila==-1) return;
        int id = (int) tblPacientes.getValueAt(fila, 0);
        if(JOptionPane.showConfirmDialog(this, "Desea dar de baja al Paciente ID: "+id+"?") != 0) return;
        Paciente paciente = pr.getById(id);
        if(cr.getByPaciente(paciente).size()!=0){
            JOptionPane.showMessageDialog(this, "Para dar de baja al Paciente ID: "+id+", primero debe liberar la cama que estuvo ocupando.","Error",JOptionPane.ERROR_MESSAGE);
            return;        
        }
        pr.remove(paciente);
        cargarElementos();             
    }//GEN-LAST:event_jButton1ActionPerformed

    private void limpiar(){
                txtNombre.setText(""); 
                txtNombre.requestFocus();
                txtApellido.setText(""); 
                txtDireccion.setText(""); 
                txtTelefono.setText(""); 
                cmbCategoria.setSelectedIndex(0);
                txtFechaCategorizacion.setText("");
                cmbIdMedicos.setSelectedIndex(0);
    }
    
    public boolean validar(){
        if(!new Validator(txtNombre).length(3, 20)) return false;
        if(!new Validator(txtApellido).length(3, 20)) return false;
        if(!new Validator(txtDireccion).length(3, 20)) return false;
        if(!new Validator(txtTelefono).length(3, 20)) return false;
        if(!new Validator(txtFechaCategorizacion).length(10, 10)) return false;
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDaDeAlta;
    private javax.swing.JComboBox<CategoriaEnum> cmbCategoria;
    private javax.swing.JComboBox<Medico> cmbIdMedicos;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JTable tblPacientes;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscarCategoria;
    private javax.swing.JTextField txtBuscarPaciente;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtFechaCategorizacion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
