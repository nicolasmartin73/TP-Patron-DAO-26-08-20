package ar.com.centrocovid.gui;
import ar.com.centrocovid.connectors.Connector;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.entities.Paciente;
import ar.com.centrocovid.repositories.interfaces.I_PacienteRepository;
import ar.com.centrocovid.repositories.jdbc.PacienteRepository;
import ar.com.centrocovid.utils.swing.Table;
public class ListadoDePacientes extends javax.swing.JInternalFrame {
    private I_PacienteRepository pr = new PacienteRepository(Connector.getConnection());
    private Medico medico;
    public ListadoDePacientes(Medico medico) {
        super( 
                "Listado de Pacientes",           //title
                false,                           //resizable
                true,                           //closable - boton de cerrar
                false,                           //maximizable - boton de maximizar
                true                            //iconable - boton de minimizar
        );
        initComponents();
        this.medico=medico;       
        cargarElementos(medico);
    }

    private void cargarElementos(Medico medico1) {
        //Cargar Medico
        txtId.setText(medico1.getId() + "");
        txtMedico.setText(medico1.getApellido());
        
        //Cargar Pacientes
        new Table<Paciente>().cargar(tblPacientes, pr.getByMedico(medico1));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtMedico = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPacientes = new javax.swing.JTable();

        jLabel1.setText("Id:");

        jLabel2.setText("Dr.");

        txtId.setEditable(false);

        txtMedico.setEditable(false);

        jScrollPane1.setViewportView(tblPacientes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addGap(4, 4, 4)
                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(148, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblPacientes;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMedico;
    // End of variables declaration//GEN-END:variables
}
