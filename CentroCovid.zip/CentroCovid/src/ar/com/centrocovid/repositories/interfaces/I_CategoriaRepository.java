package ar.com.centrocovid.repositories.interfaces;
import ar.com.centrocovid.entities.Categoria;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public interface I_CategoriaRepository {
    void save (Categoria categoria);    
    void remove (Categoria categoria);
    void update(Categoria categoria);
    List<Categoria> getAll();
    
    default Stream<Categoria> getStream(){
        return getAll().stream();
    }
    
    default Categoria getById(int id){
        return getStream().filter(a->a.getId()==id).findAny().orElse(new Categoria());
    }
    
    default List<Categoria>getLikeCategoria(Categoria categoria){
        if(categoria==null) return new ArrayList<Categoria>();
        return getStream()
            .filter(a->a.getCategoria().toString().toLowerCase().contains(categoria.toString().toLowerCase()))
            .collect(Collectors.toList());
    }
    /* Tengo un problema para poder listar consultar que corrsponden a Enums*/
    
    default List<Categoria>getById(Categoria categoria){
        if(categoria==null) return new ArrayList<Categoria>();
        return getStream()
            .filter(a->a.getId()==categoria.getId())
            .collect(Collectors.toList());
    }       
}
