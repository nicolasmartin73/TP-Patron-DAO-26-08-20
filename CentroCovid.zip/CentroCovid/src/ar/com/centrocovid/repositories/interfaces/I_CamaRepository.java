package ar.com.centrocovid.repositories.interfaces;
import ar.com.centrocovid.entities.Cama;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.entities.Paciente;
import ar.com.centrocovid.enums.EstadoEnum;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public interface I_CamaRepository {
    void save(Cama cama);
    
    void remove(Cama cama);
    
    void update(Cama cama);
    
    List<Cama> getAll();
    default Stream<Cama> getStream(){
        return getAll().stream();
    }
    
    default Cama getById(int id){
        return getStream().filter(a->a.getId()==id).findAny().orElse(new Cama());          
    }
    
    default List<Cama> getByEstado(EstadoEnum estado){
        if(estado==null) return new ArrayList<Cama>();
        return getStream()
                .filter(a->a.getEstado().toString().toLowerCase().contains(estado.toString().toLowerCase())) 
                .collect(Collectors.toList());
    }
    
    default Cama getByIdPaciente(int idpaciente){
        return getStream().filter(a->a.getIdpaciente()==idpaciente).findAny().orElse(new Cama());    
    }
    
    default List<Cama>getByPaciente(Paciente paciente){
        if(paciente==null) return new ArrayList<Cama>();
        return getStream()
            .filter(a->a.getIdpaciente()==paciente.getId())
            .collect(Collectors.toList());
    }    
    
    /*
    ¿Como generar desde esta interfaz un código el cual me permita obtener el nombre y apellido del paciente que tiene ese IdPaciente ?
    */    
}
