package ar.com.centrocovid.repositories.interfaces;
import ar.com.centrocovid.entities.Categoria;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.enums.CategoriaEnum;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public interface I_MedicoRepository {
    void save(Medico medico);
    
    void remove (Medico medico);
    
    void update(Medico medico);
    
    List<Medico> getAll();
    
    default Stream<Medico> getStream(){
        return getAll().stream();
    }
    
    default Medico getById(int id){
        return getStream().filter(a->a.getId()==id).findAny().orElse(new Medico());
    }
    
    default List<Medico>getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Medico>();
        return getStream()
            .filter(a->a.getNombre().toLowerCase().contains(nombre.toLowerCase()))
            .collect(Collectors.toList());
    }
    
    default List<Medico>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList<Medico>();
        return getStream()
            .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
            .collect(Collectors.toList());
    }
    
    default List<Medico>getByCategoria(CategoriaEnum categoria){
        if(categoria==null) return new ArrayList<Medico>();
        return getStream()
            .filter(a->a.getCategoria().toString().toLowerCase().contains(categoria.toString().toLowerCase()))
            .collect(Collectors.toList());
    }
    
    
}
