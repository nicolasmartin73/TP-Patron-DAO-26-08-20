package ar.com.centrocovid.repositories.jdbc;
import ar.com.centrocovid.entities.Cama;
import ar.com.centrocovid.enums.EstadoEnum;
import ar.com.centrocovid.repositories.interfaces.I_CamaRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class CamaRepository implements I_CamaRepository{
    private Connection conn;

    public CamaRepository(Connection conn) {
        this.conn = conn;
    }    
    
    @Override
    public void save(Cama cama) {
        if(cama==null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into camas(estado,idpaciente)"
                + "values(?,?)",PreparedStatement.RETURN_GENERATED_KEYS
        )){
            ps.setString(1, cama.getEstado().toString());
            ps.setInt(2, cama.getIdpaciente());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) cama.setId(rs.getInt(1));            
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Cama cama) {
        if(cama==null) return;
        try (PreparedStatement ps = conn.prepareStatement("delete from camas where id=?")){
            ps.setInt(1, cama.getId());
            ps.execute();            
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void update(Cama cama) {
        if(cama==null) return;
        try (PreparedStatement ps = conn.prepareStatement("update camas set estado=?, "
                + "idpaciente=? where id=?")){
            ps.setString(1, cama.getEstado().toString());
            ps.setInt(2, cama.getIdpaciente());
            ps.setInt(3, cama.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Cama> getAll() {
        List<Cama>list=new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from camas")){
            while(rs.next()){
                list.add(new Cama(
                        rs.getInt("id"),
                        EstadoEnum.valueOf(rs.getString("estado")), 
                        rs.getInt("idpaciente")
                ));
            }
            
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
