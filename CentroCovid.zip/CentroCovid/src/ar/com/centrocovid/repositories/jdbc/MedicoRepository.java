package ar.com.centrocovid.repositories.jdbc;
import ar.com.centrocovid.entities.Medico;
import ar.com.centrocovid.enums.CategoriaEnum;
import ar.com.centrocovid.repositories.interfaces.I_MedicoRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
public class MedicoRepository implements I_MedicoRepository{
    private Connection conn;

    public MedicoRepository(Connection conn) {
        this.conn = conn;
    }    

    @Override
    public void save(Medico medico) {
        if(medico==null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into medicos(nombre,apellido,direccion,telefono,categoria)"
                + "values(?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS
        )){
            ps.setString(1, medico.getNombre());
            ps.setString(2, medico.getApellido());
            ps.setString(3, medico.getDireccion());
            ps.setString(4, medico.getTelefono());
            ps.setString(5, medico.getCategoria().toString());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) medico.setId(rs.getInt(1));            
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Medico medico) {
        if(medico==null) return;
        try (PreparedStatement ps = conn.prepareStatement("delete from medicos where id=?")){
            ps.setInt(1, medico.getId());
            ps.execute();            
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void update(Medico medico) {
        if(medico==null) return;
        try (PreparedStatement ps = conn.prepareStatement("update medicos set nombre=?, "
                + "apellido=?, direccion=?, telefono=?, categoria=? where id=?")){
            ps.setString(1, medico.getNombre());
            ps.setString(2, medico.getApellido());
            ps.setString(3, medico.getDireccion());
            ps.setString(4, medico.getTelefono());
            ps.setString(5, medico.getCategoria().toString());
            ps.setInt(6, medico.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Medico> getAll() {
        List<Medico>list=new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from medicos")){
            while(rs.next()){
                list.add(new Medico(
                        rs.getInt("id"),
                        rs.getString("nombre"), 
                        rs.getString("apellido"), 
                        rs.getString("direccion"), 
                        rs.getString("telefono"), 
                        CategoriaEnum.valueOf(rs.getString("categoria"))
                ));
            }
            
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
    
}
