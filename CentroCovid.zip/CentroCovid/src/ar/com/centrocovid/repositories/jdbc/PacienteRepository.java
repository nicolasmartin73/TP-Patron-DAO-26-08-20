package ar.com.centrocovid.repositories.jdbc;
import ar.com.centrocovid.entities.Paciente;
import ar.com.centrocovid.enums.CategoriaEnum;
import ar.com.centrocovid.repositories.interfaces.I_PacienteRepository;
import java.sql.Connection;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
public class PacienteRepository implements I_PacienteRepository{
    private Connection conn;

    public PacienteRepository(Connection conn) {
        this.conn = conn;
    }
    
    @Override
    public void save(Paciente paciente) {
        if(paciente==null) return;
        try (PreparedStatement ps=conn.prepareStatement("insert into pacientes (nombre,apellido,direccion,telefono,categoria,fechacategorizacion,idmedico)"
                + "values (?,?,?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS
        )){
            ps.setString(1, paciente.getNombre());
            ps.setString(2, paciente.getApellido());
            ps.setString(3, paciente.getDireccion());
            ps.setString(4, paciente.getTelefono());
            ps.setString(5, paciente.getCategoria().toString());
            ps.setString(6, paciente.getFechacategorizacion());
            ps.setInt(7, paciente.getIdmedico());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) paciente.setId(rs.getInt(1));            
        } catch (Exception e) {e.printStackTrace(); }
    }

    @Override
    public void remove(Paciente paciente) {
        if(paciente==null) return;
        try (PreparedStatement ps = conn.prepareStatement("delete from pacientes where id=?")){
            ps.setInt(1, paciente.getId());
            ps.execute();            
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void update(Paciente paciente) {
        if(paciente==null) return;
        try (PreparedStatement ps = conn.prepareStatement("update pacientes set nombre=?, "
                + "apellido=?, direccion=?, telefono=?, categoria=?, fechacategorizacion=?, idmedico=? where id=?")){
            ps.setString(1, paciente.getNombre());
            ps.setString(2, paciente.getApellido());
            ps.setString(3, paciente.getDireccion());
            ps.setString(4, paciente.getTelefono());
            ps.setString(5, paciente.getCategoria().toString());
            ps.setString(6, paciente.getFechacategorizacion());
            ps.setInt(7, paciente.getIdmedico());           
            ps.setInt(8, paciente.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Paciente> getAll() {
        List<Paciente>list=new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from pacientes")){
            while(rs.next()){
                list.add(new Paciente(
                        rs.getInt("id"),
                        rs.getString("nombre"), 
                        rs.getString("apellido"), 
                        rs.getString("direccion"), 
                        rs.getString("telefono"), 
                        CategoriaEnum.valueOf(rs.getString("categoria")),
                        rs.getString("fechacategorizacion"), 
                        rs.getInt("idmedico")
                ));
            }            
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
